<?php

/**
 * @package list-plugin
 */
/*
Plugin Name: my post list plugin
Plugin URI: https://enthalpy.mx/
Description: Used by millions, Akismet is quite possibly the best way in the world to <strong>protect your blog from spam</strong>. It keeps your site protected even while you sleep. To get started: activate the Akismet plugin and then go to your Akismet Settings page to set up your API key.
Version: 5.1
Requires at least: 5.0
Requires PHP: 5.2
Author: Automattic
Author URI: https://automattic.com/wordpress-plugins/
License: GPLv2 or later
Text Domain: list-plugin
*/

//function get post list attributes
function get_post_list_atts($atts){
    return shortcode_atts([
        "category" => "",
    ],$atts);
}

//function query post by category
function query_post_by_category($category){
    $args = [
        "category_name" => $category,
    ];
    return get_posts($args);
}

// function generate the output
function generate_post_list_output($posts){
    $output = "No posts found";
    if($posts){
        $output ='<ul>';
        foreach($posts as $post){
            $output .= '<li><a href="'.get_permalink($post).'">'.$post->post_title.'</a></li>';
        }
        $output .= '</ul>';
    }

    return $output;
}

//shortcode function
function my_post_list_shortcode($atts){
    try {
        //create the output
        $atts = get_post_list_atts($atts);
        $post = query_post_by_category($atts["category"]);
        $output = generate_post_list_output($post);
    } catch (Exception $e) {
        $output = 'An error happend while processing shortcode';
        error_log('An error happend while processing shortcode: '.$e->getMessage());
    }
    
    return $output;
}

//function to add the shotrcode
add_shortcode("my_post_list", "my_post_list_shortcode");

?>