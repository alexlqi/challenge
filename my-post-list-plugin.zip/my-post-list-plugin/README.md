# My Post List Plugin

This plugin adds a new shortcode [my_post_list category=""] that displays a list of posts filtered by a specific category.

## Installation

1. Download the my-post-list-plugin folder.
2. Upload the folder to the wp-content/plugins directory.
3. Activate the plugin from the WordPress admin panel.

## Usage

To display a list of posts filtered by a specific category, use the following shortcode:

```
[my_post_list category="category-slug"]
```

Replace `category-slug` with the slug of the category by which to filter the posts.